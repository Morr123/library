<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Category;
use app\models\Relation;
use app\models\Book;

use app\models\UploadForm;
use yii\web\UploadedFile;


class AdminController extends Controller
{
    public $layout = 'admin';
    
    public function actionIndex()
    {
        $model = new Category();
        $cat = Category::find()->with('book')->all();
        return $this->render('index', ['cat'=>$cat, 'model'=>$model]);
    }
    
    public function actionDeletecat($id)
    {
        $cat = Category::findOne($id);
        $cat->delete();
        return $this->redirect(['index']);
    }
    
    public function actionCreatecat()
    {
        $model = new Category();
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        }
    }
    public function actionUpdatecat($id)
    {
        $model = new Category();
        $model = $model->findOne($id);
        
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        }
        else {
            return $this->render('updatecat', [
                'model' => $model,
            ]);
        }
        
    }
    
    public function actionMovebook()
    {
        $param = Yii::$app->request->getBodyParams();
        foreach($param as $key=>$val)
        {
            if(is_int($key))
            {
                Relation::deleteAll(['id_book'=>$key]);
                
                $model = new Relation();
                $model->id_book = $key;
                $model->id_category = $param['category'];
                $model->save();
            }
        }
        
        return $this->redirect(['index']);
    }
    
    public function actionBook()
    {
        $book = Book::find()->with('category')->all();
        return $this->render('book', ['books'=>$book]);
    }
    
    public function actionCreatebook()
    {
        $cat = Category::find()->all();
        $dir = realpath(dirname(__FILE__)).'\..\web\img\book\\';
        $dir2 = realpath(dirname(__FILE__)).'\..\web\books\\';
        $uploaded = false;
        
        $model = new Book();
        

        if ($model->load(Yii::$app->request->post())) {
            
            $file = UploadedFile::getInstance($model, 'file');
            $file2 = UploadedFile::getInstance($model, 'file2');
            if(!is_null($file)) {
            $model->foto = $file;
            if ($model->validate()) {
                $uploaded = $file->saveAs( $dir . $model->foto );
            }
            }
            if(!is_null($file2))
            {
                $model->ssilka = $file2;
                if ($model->validate()) {
                    $uploaded = $file2->saveAs( $dir2 . $model->ssilka );
                }
                
            }
            $model->save();
           $rel = new Relation();
           $rel->id_book = $model->id;
           $rel->id_category = $_POST['cat'];
           $rel->save();
           
           return $this->redirect(['book']);
            
        } else {
            return $this->render('bookcreate', [
                'model' => $model, 'cat'=>$cat
            ]);
        }
        
    }
    
    public function actionUpdatebook($id)
    {
        
        $cat = Category::find()->all();
        $dir = realpath(dirname(__FILE__)).'\..\web\img\book\\';
        $dir2 = realpath(dirname(__FILE__)).'\..\web\books\\';
        $uploaded = false;
        
        $model = new Book();
        $model = $model->findOne($id);
        
        $rel = Relation::find()->where(['id_book'=>$id])->one();
        $selectcat = $rel->id_category;
        
        
        if ($model->load(Yii::$app->request->post())) {
                
            $file = UploadedFile::getInstance($model, 'file');
            $file2 = UploadedFile::getInstance($model, 'file2');
            
            if(!is_null($file)) {
                $model->foto = $file;
                if ($model->validate()) {
                    $uploaded = $file->saveAs( $dir . $model->foto );
                }
            }
            if(!is_null($file2))
            {
                $model->ssilka = $file2;
                if ($model->validate()) {
                     $uploaded = $file2->saveAs( $dir2 . $model->ssilka );
                }
                
            }
            $model->save();
            
            $rel = new Relation();
            $rel = $rel->find()->where(['id_book'=>$model->id])->one();
            $rel->id_category=$_POST['cat'];
            $rel->save();
            
            return $this->redirect(['book']);
            
        }
            
       else {
            
            return $this->render('bookupdate', [
                'model' => $model, 'cat'=>$cat, 'selectcat'=>$selectcat,
            ]);
        }
        
    }
    
    public function actionDeletebook($id)
    {
        $cat = Book::findOne($id);
        $cat->delete();
        return $this->redirect(['book']);
        
    }
    
    
}