<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Category;
use app\models\Book;
use app\models\Relation;
use app\models\BookSearch;

class LibraryController extends Controller
{
    public $layout = 'library';
    
    public $cat;
    
    public function actions()
    {
        $this->cat = Category::find()->all();
    }
    
    public function actionIndex()
    {
        $searchModel = new BookSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        return $this->render('index', ['cat'=>$this->cat,'book'=>$dataProvider->getModels()]);
    }
    
    public function actionCategory($id)
    {
        $book = Relation::find()->with('book')->where(['id_category'=>$id])->all();
        return $this->render('index', ['cat'=>$this->cat,'book'=>$book]);
    }
    
    public function actionBook($id)
    {
        $book = Book::findOne($id);
        return $this->render('book', ['cat'=>$this->cat, 'book'=>$book]);
    }
    
    public function actionSort($later)
    {
        $book = Book::find()->filterWhere(['like','name',$later.'%',false])->all();
        return $this->render('index', ['cat'=>$this->cat,'book'=>$book]);
    }
    
    public function actionDownload($file)
    {
        $file = realpath(dirname(__FILE__)).'\..\web\books\\'.$file;
        
        if (file_exists($file)) {
            Yii::$app->response->sendFile($file);
        }
        
        $mail = Yii::$app->params['adminEmail'];
        $sub = 'Книга';
        $message = 'Скачали книгу:'.$book;
        mail($mail, $sub, $message); 
    }
    
}