<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=library',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
