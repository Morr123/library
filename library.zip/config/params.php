<?php

return [
    'adminEmail' => 'gorka4646@yandex.ru',
];
