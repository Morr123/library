<?php

namespace app\models;

use Yii;
use yii\web\UploadedFile;

/**
 * This is the model class for table "book".
 *
 * @property integer $id
 * @property string $name
 * @property string $descript
 * @property string $foto
 *
 * @property Relation $id0
 * @property Relation[] $relations
 */
class Book extends \yii\db\ActiveRecord
{
    public $file;
    public $file2;
    public $cat;
    
    
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'book';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['file2'], 'file', 'extensions' => 'txt'],
            [['file'], 'file', 'extensions' => 'png, jpg'],
            [['name', 'descript'], 'required'],
            [['descript'], 'string'],
            //[['name', 'foto'], 'string', 'max' => 100],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => Relation::className(), 'targetAttribute' => ['id' => 'id_book']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Название',
            'descript' => 'Описание',
            'foto' => 'Фото',
            'file'=>'Картинка',
            'file2'=>'Книга',
            'cat'=>''
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(Relation::className(), ['id_book' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRelations()
    {
        return $this->hasMany(Relation::className(), ['id_book' => 'id']);
    }
    
    public function getCategory()
    {
        return $this->hasMany(Category::className(), ['id'=>'id_category'])->viaTable('relation', ['id_book'=>'id']);
    }
    
}
