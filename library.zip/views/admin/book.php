<?php
use yii\helpers\Url;   
?>
<h1>Книги</h1>
<h3><a href="<?= Url::toRoute(['admin/createbook']) ?>">Добавить книгу</a></h3>
<?php foreach($books as $book) : ?>
<?php $cat = $book->category; ?>
<div class="row">
    <div class="col-sm-3">
        <h5><?= $book->name ?></h5>
    </div>
    <div class="col-sm-4">
        <h5><?= $book->descript ?></h5>
    </div>
    <div class="col-sm-2">
        <h5><?= $cat[0]->name ?></h5>
    </div>
    <div class="col-sm-1">
        <a href="<?= Url::toRoute(['admin/deletebook', 'id'=>$book->id]) ?>">Удалить</a>
    </div>
    <div class="col-sm-1">
        <a href="<?= Url::toRoute(['admin/updatebook', 'id'=>$book->id]) ?>">Редактировать</a>
    </div>
</div>
<?php endforeach; ?>