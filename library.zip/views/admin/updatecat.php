<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

?>
<h1>Редактировать категорию</h1>
<?= $this->render('_formcat', [
        'model' => $model, 'action'=>'updatecat?id='.$model->id,
    ]) ?>