<h1>Редактировать книгу</h1>
<div class="col-sm-6">
<?= $this->render('_formbook', [
        'model' => $model, 'cat'=>$cat, 'selectcat'=>$selectcat, 'type'=>'update',
    ]) ?>
</div>