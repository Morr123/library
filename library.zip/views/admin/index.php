<?php
/* @var $this yii\web\View */
use yii\helpers\Url;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
$this->title = 'M222y Yii Application';
?>
<h1>Категории</h1>
<?= $this->render('_formcat', [
        'model' => $model, 'action'=>'createcat',
    ]) ?>
    
<?php $form = ActiveForm::begin([
            'action' => ['movebook'],
            'method' => 'post',
        ]); ?>
        
<?php $ind = 0 ; foreach($cat as $val) : ?>
<?php $books = $val->book; $ind++ ?>
<div class="row">
    <div class="col-sm-4">
        <h2><a data-toggle="collapse" data-parent="#accordion" href="#collapse-<?= $ind ?>"><?= $val->name ?></a></h2>
            <div id="collapse-<?= $ind ?>" class="panel-collapse collapse">
                <div class="panel-body">
                    <ul>
                        <?php foreach($books as $book) : ?>
                            <li><input name="<?= $book->id ?>" value="<?= $book->id ?>" type="checkbox" /><?= $book->name ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
    </div>
    <div class="col-sm-2 cat-admin">
        <a href="<?= Url::toRoute(['admin/deletecat', 'id'=>$val->id]) ?>">Удалить</a>
    </div>
    <div class="col-sm-2 cat-admin">
        <a href="<?= Url::toRoute(['admin/updatecat', 'id'=>$val->id]) ?>">Редактировать</a>
    </div>
</div>
<?php  endforeach; ?>

<h3>Переместить выбранные книги в :</h3>
<select name="category">
<?php foreach($cat as $val) : ?>
  <option value="<?= $val->id ?>"><?= $val->name ?></option>
<?php  endforeach; ?>
</select>
<input type="submit">
<?php ActiveForm::end(); ?>
