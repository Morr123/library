<?php

use yii\helpers\Html;

use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;


?>
<?php 
    $items = ArrayHelper::map($cat,'id','name');
    if(isset($selectcat))
    {
        $param = ['options' =>[ $selectcat => ['Selected' => true] ] ];
    }
    else
    {
        $param = null;
    }
?>
<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'descript')->textarea(['rows' => 6]) ?>
    
    <?php if($type=='update') : ?>
        <img src="<?= Yii::$app->getUrlManager()->getBaseUrl() ?>/web/img/book/<?= $model->foto ?>">
    <?php endif; ?>
    
    <?= $form->field($model, 'file')->fileInput() ?>
    
    
    <?php if($type=='update') : ?>
        <a href="<?= Yii::$app->getUrlManager()->getBaseUrl() ?>/web/book/<?= $model->ssilka ?>"><?= $model->ssilka ?></a>
    <?php endif; ?>
    
    <?= $form->field($model, 'file2')->fileInput() ?>
    
    <?php /*$form->field($model, 'cat')->dropDownList($items)*/ ?>
    
     <?= Html::dropDownList('cat', 'null', $items, $param) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Создать' : 'Обновить', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

<?php ActiveForm::end(); ?>
