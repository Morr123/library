<h1>Добавьте книгу</h1>
<div class="col-sm-6">
<?= $this->render('_formbook', [
        'model' => $model, 'cat'=>$cat
    ]) ?>
</div>