<?php
/* @var $this yii\web\View */
use yii\helpers\Url;
use yii\widgets\ActiveForm;
$this->title = 'M222y Yii Application';
?>
<ul class="nav">
     <?php $form = ActiveForm::begin([
            'action' => ['index'],
            'method' => 'get',
        ]); ?>
    <li><input name="BookSearch[name]" type="text"></li>
    <li><input type="submit"></li>
    
    <?php ActiveForm::end(); ?>
    
    <li><a href="<?= Yii::$app->getUrlManager()->getBaseUrl() ?>">Все категории</a></li>
<?php foreach($cat as $val) : ?>
      <li><a href="<?= Url::toRoute(['library/category', 'id'=>$val->id]) ?>"><?= $val->name ?></a></li>  
<?php endforeach; ?>
</ul>
<div class="row">
<?php foreach($book as $val) : ?>
    <div class="col-sm-3">
        <?php if(isset($val->book)) : $val = $val->book;  endif; ?>
        <h3><a href="<?= Url::toRoute(['library/book', 'id'=>$val->id]) ?>"><?= $val->name ?></a></h3>
        <img src="<?= Yii::$app->getUrlManager()->getBaseUrl() ?>/web/img/book/<?= $val->foto ?>">
    </div>
<?php endforeach; ?>
</div>


